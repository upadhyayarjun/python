/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author Arjun
 */
public class SOCMailSecurityWorkRequest extends WorkRequest{
    
    String receipients;
    String emailMessage;
    String emailSubject;

    public String getEmailSubject() {
        return emailSubject;
    }

    public void setEmailSubject(String emailSubject) {
        this.emailSubject = emailSubject;
    }
    
    
    public String getReceipients() {
        return receipients;
    }

    public void setReceipients(String receipients) {
        this.receipients = receipients;
    }

    public String getEmailMessage() {
        return emailMessage;
    }

    public void setEmailMessage(String emailMessage) {
        this.emailMessage = emailMessage;
    }
    
    
    
    
}
