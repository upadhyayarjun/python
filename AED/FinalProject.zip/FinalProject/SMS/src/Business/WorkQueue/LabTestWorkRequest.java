/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Person.Patient;
import Business.UserAccount.UserAccount;

/**
 *
 * @author Arjun
 */
public class LabTestWorkRequest extends WorkRequest{
    
    private String labTestResult;
    private UserAccount docSender;
    private UserAccount labReceiver;
    private String diagnosis; 
    private String medication;
    private String detail;
    private Patient patient;
    private String testResult;
    private String testPerformed;

    public String getTestResult() {
        return testResult;
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }

    public String getTestPerformed() {
        return testPerformed;
    }

    public void setTestPerformed(String testPerformed) {
        this.testPerformed = testPerformed;
    }
    
    

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
    
    
    public String getLabTestResult() {
        return labTestResult;
    }

    public void setLabTestResult(String labTestResult) {
        this.labTestResult = labTestResult;
    }

    public UserAccount getDocSender() {
        return docSender;
    }

    public void setDocSender(UserAccount docSender) {
        this.docSender = docSender;
    }

    public UserAccount getLabReceiver() {
        return labReceiver;
    }

    public void setLabReceiver(UserAccount labReceiver) {
        this.labReceiver = labReceiver;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getMedication() {
        return medication;
    }

    public void setMedication(String medication) {
        this.medication = medication;
    }
    

    
}
