/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.UserAccount.UserAccount;

/**
 *
 * @author Arjun
 */
public class HRWorkRequest extends WorkRequest{
    
   private UserAccount employee;
   private String violation;

    public UserAccount getEmployee() {
        return employee;
    }

    public void setEmployee(UserAccount employee) {
        this.employee = employee;
    }

    public String getViolation() {
        return violation;
    }

    public void setViolation(String violation) {
        this.violation = violation;
    }
    
   
    
    
}
