/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Vitals;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Arjun
 */
public class VitalSigns {
    
    private int respiratoryRate;
    private int heartRate;
    private int bloodPressure;
    private double weight;
    private Date time;
    SimpleDateFormat format ;
    private String condition;
    
    public VitalSigns()
       {
                format = new SimpleDateFormat("MM:dd:yyyy hh:mm:ss a");
        }
     public int getRespiratoryRate() {
        return respiratoryRate;
    }

    public void setRespiratoryRate(int respiratoryRate) {
        this.respiratoryRate = respiratoryRate;
    }

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

    public int getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(int bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }
    
    @Override
    public String toString(){
        return this.condition;
    }
}
