/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Vitals;


import java.util.ArrayList;

/**
 *
 * @author Arjun
 */
public class VitalsignHistory {
    
    private ArrayList<VitalSigns> vitalSignHistory;
    
    public VitalsignHistory(){
        
        vitalSignHistory = new ArrayList<>();
    }

    public ArrayList<VitalSigns> getVitalSignHistory() {
        return vitalSignHistory;
    }
    
    public VitalSigns createVitalSign() {
        VitalSigns vs = new VitalSigns();
        vitalSignHistory.add(vs);
        
        return vs;
    }
}
