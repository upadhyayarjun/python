/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.PatientBill.PatientBillDirectory;
import Business.Vitals.VitalsignHistory;

/**
 *
 * @author Arjun
 */
public class Patient extends Person{
    
    private int patientID;
    private static int count = 0;
    private VitalsignHistory vitalsignHistory;
    private PatientBillDirectory pbd;
    private boolean selfregistered = false;
    
    
    public Patient()
    {
      patientID = count;
      count++;
      vitalsignHistory = new VitalsignHistory();
      pbd = new PatientBillDirectory();
    }

    public boolean isSelfregistered() {
        return selfregistered;
    }

    public void setSelfregistered(boolean selfregistered) {
        this.selfregistered = selfregistered;
    }

    
    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public VitalsignHistory getVitalsignHistory() {
        return vitalsignHistory;
    }

    public void setVitalsignHistory(VitalsignHistory vitalsignHistory) {
        this.vitalsignHistory = vitalsignHistory;
    }

    public PatientBillDirectory getPbd() {
        return pbd;
    }

    public void setPbd(PatientBillDirectory pbd) {
        this.pbd = pbd;
    }
    
    
    
    @Override
    public String toString()
    {
        return this.getfName()+" "+this.getlName();
    }
}
