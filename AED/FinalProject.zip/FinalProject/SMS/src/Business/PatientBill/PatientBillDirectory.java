/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.PatientBill;

import java.util.ArrayList;

/**
 *
 * @author Arjun
 */
public class PatientBillDirectory {
    
    private ArrayList<PatientBill> patientBills;
    
    public PatientBillDirectory()
    {
        patientBills = new ArrayList<>();
    }

    public ArrayList<PatientBill> getPatientBills() {
        return patientBills;
    }
    
     public PatientBill createBill() {
        PatientBill pb = new PatientBill();
        patientBills.add(pb);
        
        return pb;
    }
     
     public void deleteBill(PatientBill pb)
     {
         patientBills.remove(pb);
     }
    
}
