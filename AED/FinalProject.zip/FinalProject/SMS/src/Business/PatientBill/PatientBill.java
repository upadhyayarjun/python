/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.PatientBill;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Arjun
 */
public class PatientBill {
    
    double registrationCharge;
    double doctorFees;
    double coPay;
    double total;
    private Date time;
    SimpleDateFormat format = new SimpleDateFormat("MM:dd:yyyy hh:mm:ss a");
    
    public PatientBill()
    {
        
    }

    public double getRegistrationCharge() {
        return registrationCharge;
    }

    public void setRegistrationCharge(double registrationCharge) {
        this.registrationCharge = registrationCharge;
    }

    public double getDoctorFees() {
        return doctorFees;
    }

    public void setDoctorFees(double doctorFees) {
        this.doctorFees = doctorFees;
    }

    public double getCoPay() {
        return coPay;
    }

    public void setCoPay(double coPay) {
        this.coPay = coPay;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
    
    @Override
    public String toString(){
        return String.valueOf(this.total);
    }
}
