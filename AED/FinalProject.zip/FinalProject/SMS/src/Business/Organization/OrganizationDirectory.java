/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import java.util.ArrayList;

/**
 *
 * @author Arjun
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList<>();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(String name,Organization.Type type){
        Organization organization = null;
        if (type.getValue().equals(Organization.Type.Doctor.getValue())){
            organization = new DoctorOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.AdminOrganization.getValue())){
            organization = new AdminOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.SOC.getValue())){
            organization = new SOCOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.ITEmployee.getValue())){
            organization = new ITEmployeeOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.Lab.getValue())){
            organization = new LabOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.Nurse.getValue())){
            organization = new NurseOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.Patient.getValue())){
            organization = new PatientOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.FinSOC.getValue())){
            organization = new FinanceSOCOrganization(name);
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.FinanceAdmin.getValue())){
            organization = new FinanceAdminOrganization(name);
            organizationList.add(organization);
        }
         else if (type.getValue().equals(Organization.Type.FinanceHR.getValue())){
            organization = new HRFinanceOrganization(name);
            organizationList.add(organization);
        }
         else if (type.getValue().equals(Organization.Type.HospitalHR.getValue())){
            organization = new HRHospitalOrganization(name);
            organizationList.add(organization);
        }
        
        
        
        
        
        return organization;
    }
    
    public void deleteOrganization(Organization organization){
        organizationList.remove(organization);
    }
}
