/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;

/**
 *
 * @author Arjun
 */
public abstract class Role {
    
    private RoleType roleType;
    
    public Role(RoleType type){
        this.roleType = type;
    }
    
    public enum RoleType{
        EnterpriseAdmin("Admin"),
        Doctor("Doctor"),
        LabAssistant("Lab Assistant"),
        ITEmployee("IT Employee"),
        NetworkAdmin("Network Admin"),
        NetworkSOC("Network SOC"),
        Nurse("Nurse"),
        OrganizationSOC("Organization SOC"),
        Patient("Patient"),
        OrganizationAdmin("OrganizationAdmin"),
        FinSOC("Finance SOC"),
        FinanceHR("Finance HR"),
        HospitalHR("Hospital HR"),
        FinAdmin("Finance Admin");
        
        private String value;
        private RoleType(String value){
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    public RoleType getRoleType() {
        return roleType;
    }

    public void setRoleType(RoleType roleType) {
        this.roleType = roleType;
    }
    
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer, 
            UserAccount account, 
            Organization organization, 
            Enterprise enterprise, 
            EcoSystem business);

    @Override
    public String toString() {
        return this.roleType.getValue();
    }
    
    
}
