/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.EnterpriseAdmin.EnterpriseAdminWorkArea;
import javax.swing.JPanel;

/**
 *
 * @author Arjun
 */
public class EnterpriseAdminRole extends Role{
    
    public EnterpriseAdminRole(){
        super(RoleType.EnterpriseAdmin);
    }

    @Override
    public JPanel createWorkArea(JPanel upc, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        return new EnterpriseAdminWorkArea (upc, account,organization,enterprise,business);
        
    }

    
    
}
