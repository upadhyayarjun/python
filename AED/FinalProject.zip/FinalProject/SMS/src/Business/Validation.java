/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Arjun
 */
public class Validation {
   
    public static boolean isContact(String a)
{
    try{
        Long num = Long.parseLong(a);
        if(a.length() == 10)
        return true;
        else
            return false;
    }
    catch(Exception e)
    {
         return false;
    }
}
     public static boolean isNumber(String a)
{
    try{
        int num = Integer.parseInt(a);
        if(num > 0)
        return true;
        else
            return false;
    }
    catch(Exception e)
    {
         return false;
    }
}
     public static boolean isString(String b)
     {
         if(b.matches("[a-z A-Z _ - 0-9]*$"))
         {
             return true;
         }
         else
         {
             return false;
         }
     }
     public static boolean isFloat (String c)
    {        
       try
       {
         float f = Float.parseFloat(c);
         return true;
        }
     catch(Exception e)
        {
            return false;
        }
}
     
     public static boolean isDouble (String string)
    {        
       try
       {
         double d = Double.parseDouble(string);
         return true;
        }
     catch(Exception e)
        {
            return false;
        }
    }
     public static boolean isAlpha(String s)
     {
        
            if(s.matches("[A-Z a-z]*$"))
         {
             return true;
             
         }else
         {
             return false;
         }
        
     }
     
     public static boolean isEmail(String e)
     {
         try
        {
         if(e.matches("^[\\p{L}\\p{N}\\._%+-]+@[\\p{L}\\p{N}\\.\\-]+\\.[\\p{L}]{2,}$"))
         {
             return true;
         }
         else
         {
             return false;
         }
         }catch(Exception z)
                {
                    return false;
                }
     }
     
     
     public static boolean isPassword(String p)
     {
      
         if(p.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"))
         {
             return true;
         }
         else
         {
             return false;
         }
     }
     
     public static String isCondition (int age,int resp, int bp, Double wt, int hr)
     {
         if ((age >= 1 && age<= 3) && (resp>=20 && resp<=30)&&(bp>=80 && bp<=110)&&(wt>=22 && wt<=31) && (hr>=80 && hr<=130))
         {
             return "Normal";
         }
         else if ((age >= 4 && age<= 5) && (resp>=20 && resp<=30)&&(bp>=80 && bp<=110)&&(wt>=31 && wt<=40) && (hr>=80 && hr<=120))
         {
             return "Normal";
         }
         else if ((age >= 6 && age<= 12) && (resp>=20 && resp<=30)&&(bp>=80 && bp<=120)&&(wt>=41 && wt<=92) && (hr>=70 && hr<=110))
         {
             return "Normal";
         }
         else if ((age >= 13) && (resp>=12 && resp<=20)&&(bp>=110 && bp<=120)&&(wt>110) && (hr>=55 && hr<=105))
         {
             return "Normal";
         }
         else
            return "Abnormal";
       
     }
}

