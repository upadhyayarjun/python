-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: restaurantmanagementsystem
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcement` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcement` varchar(255) DEFAULT NULL,
  `announcementdate` datetime DEFAULT NULL,
  `towhom` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement`
--

LOCK TABLES `announcement` WRITE;
/*!40000 ALTER TABLE `announcement` DISABLE KEYS */;
INSERT INTO `announcement` VALUES (1,'hi',NULL,'Chefs'),(2,'bye bye gn','2016-06-23 02:15:42','Customers'),(3,'','2016-06-23 16:08:37','Chefs'),(4,'!@#$%^&*','2016-06-28 19:51:50','Chefs'),(5,'!@#$%^&*','2016-06-28 19:54:56','Chefs'),(6,'!@#$%^&*()HFE@@#@@#$Q$W#$','2016-06-28 19:55:14','Chefs'),(7,'Free soup for order upto 20$','2016-07-01 02:24:05','Customers');
/*!40000 ALTER TABLE `announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `feedbackid` int(11) NOT NULL AUTO_INCREMENT,
  `ambienceRating` int(11) DEFAULT NULL,
  `serviceRating` int(11) DEFAULT NULL,
  `foodrating` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `feedbackBY` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`feedbackid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,3,4,'5','aweosme',19,NULL),(2,4,3,'2','super',19,NULL),(3,4,4,'4','nice one...keep up the good work guys..!!',19,NULL),(4,1,1,'1','sdffdb ,,..',19,NULL);
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food` (
  `foodid` int(11) NOT NULL AUTO_INCREMENT,
  `foodname` varchar(255) DEFAULT NULL,
  `foodtype` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `ingredients` varchar(255) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`foodid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food`
--

LOCK TABLES `food` WRITE;
/*!40000 ALTER TABLE `food` DISABLE KEYS */;
INSERT INTO `food` VALUES (1,'roti','food',4,'wheat','present'),(2,'jalebi','dessert',7.79,'floor,ghee,sugar','present'),(3,'Captain Morgan','alcohol',27.49,'Rum','not present'),(4,'cold bournvita','beverages',5.55,'bournvita,milk,ice','present'),(9,'bev Name','beverages',99.99,'bev ingredients','present'),(10,'food Name','food',70,'food ingredients','present'),(11,'alcohol name','alcohol',15,'alcohol ingredients','present'),(12,'dessert name','dessert',45,'dessert ingredients','present'),(13,'paneer tikka','food',22,'paneer','present');
/*!40000 ALTER TABLE `food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (2);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredients`
--

DROP TABLE IF EXISTS `ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingredients` (
  `ingredientid` int(11) NOT NULL AUTO_INCREMENT,
  `ingredientname` varchar(255) DEFAULT NULL,
  `food_foodid` int(11) DEFAULT NULL,
  PRIMARY KEY (`ingredientid`),
  KEY `FK3hu1drgmefabeq2ml62omgsp2` (`food_foodid`),
  CONSTRAINT `FK3hu1drgmefabeq2ml62omgsp2` FOREIGN KEY (`food_foodid`) REFERENCES `food` (`foodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredients`
--

LOCK TABLES `ingredients` WRITE;
/*!40000 ALTER TABLE `ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingredients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderitem`
--

DROP TABLE IF EXISTS `orderitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderitem` (
  `orderitemid` int(11) NOT NULL AUTO_INCREMENT,
  `specialmessage` varchar(255) DEFAULT NULL,
  `orders` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `foodid` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `chefid` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`orderitemid`),
  KEY `FKq19v83my1eok0j56w1v0uxjda` (`foodid`),
  KEY `FKrp2950dd2m6wph6g8hpt34v82` (`orders`),
  CONSTRAINT `FKq19v83my1eok0j56w1v0uxjda` FOREIGN KEY (`foodid`) REFERENCES `food` (`foodid`),
  CONSTRAINT `FKrp2950dd2m6wph6g8hpt34v82` FOREIGN KEY (`orders`) REFERENCES `ordertable` (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderitem`
--

LOCK TABLES `orderitem` WRITE;
/*!40000 ALTER TABLE `orderitem` DISABLE KEYS */;
INSERT INTO `orderitem` VALUES (34,'Special Instructions..!!',11,2,2,7.79,18,'completed'),(35,'Special Instructions..!!',12,3,1,3,18,'completed'),(36,'Special Instructions..!!',13,5,4,5.55,18,'completed'),(37,'Special Instructions..!!',14,1,9,99.99,18,'completed'),(38,'Special Instructions..!!',15,1,3,27.49,18,'completed'),(39,'Special Instructions..!!',15,1,11,85,18,'preparing'),(40,'Special Instructions..!!',16,1,1,3,0,'placed'),(41,'Special Instructions..!!',16,1,10,70,0,'placed'),(42,'Special Instructions..!!',16,1,4,5.55,0,'placed'),(43,'Special Instructions..!!',16,1,9,99.99,18,'preparing'),(44,'Special Instructions..!!',16,1,3,27.49,18,'preparing'),(45,'Special Instructions..!!',16,1,11,85,18,'preparing'),(46,'Special Instructions..!!',16,1,2,7.79,18,'completed'),(47,'Special Instructions..!!',16,1,12,45,18,'preparing'),(48,'Special Instructions..!!',17,1,3,27.49,18,'preparing'),(49,'Special Instructions..!!',18,2,4,5.55,18,'completed'),(50,'Special Instructions..!!',20,1,11,15,0,'placed');
/*!40000 ALTER TABLE `orderitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordertable`
--

DROP TABLE IF EXISTS `ordertable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordertable` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `orderdate` datetime DEFAULT NULL,
  `customerid` int(11) DEFAULT NULL,
  PRIMARY KEY (`orderid`),
  KEY `FK1g3exeh0k86px7t8d7w9ri7ip` (`customerid`),
  CONSTRAINT `FK1g3exeh0k86px7t8d7w9ri7ip` FOREIGN KEY (`customerid`) REFERENCES `person` (`personid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordertable`
--

LOCK TABLES `ordertable` WRITE;
/*!40000 ALTER TABLE `ordertable` DISABLE KEYS */;
INSERT INTO `ordertable` VALUES (11,'2016-06-30 02:04:36',19),(12,'2016-06-30 02:10:44',19),(13,'2016-06-30 03:43:39',19),(14,'2016-06-30 03:45:37',19),(15,'2016-06-30 03:45:47',19),(16,'2016-06-30 03:47:41',19),(17,'2016-06-30 03:52:15',19),(18,'2016-06-30 13:45:28',19),(19,'2016-07-01 05:00:08',19),(20,'2016-07-01 05:01:05',19);
/*!40000 ALTER TABLE `ordertable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `personid` int(11) NOT NULL AUTO_INCREMENT,
  `age` int(11) DEFAULT NULL,
  `contact` bigint(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `loginid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`personid`),
  KEY `FKm3gepnd7ai8g0y988kek6w22e` (`loginid`),
  CONSTRAINT `FKm3gepnd7ai8g0y988kek6w22e` FOREIGN KEY (`loginid`) REFERENCES `usertable` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,25,1111111111,'arjun@gmail.com','arjun u','arjun','arjun','admin',1),(18,33,10000000334,'chef@chef.com','Chef','male','chefnew','chef',22),(19,45,2000000000,'newcustomer@cust.com','customer1','male','new','customer',23);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertable`
--

DROP TABLE IF EXISTS `usertable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usertable` (
  `userid` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertable`
--

LOCK TABLES `usertable` WRITE;
/*!40000 ALTER TABLE `usertable` DISABLE KEYS */;
INSERT INTO `usertable` VALUES (1,'Admin1','admin'),(22,'Chefnew1','chefnew'),(23,'Newcust1','newcustomer');
/*!40000 ALTER TABLE `usertable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-01  5:05:44
